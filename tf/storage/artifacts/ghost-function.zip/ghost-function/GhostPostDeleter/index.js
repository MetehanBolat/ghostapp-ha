var mysql = require("mysql");
var con = null;

module.exports = async function (context, req) {
  if (!con) {
    con = mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      ssl: true,
      database: process.env.DB_DATABASE,
    });
  }

  function connect() {
    return new Promise((resolve, reject) => {
      con.connect(function (err) {
        if (!err) {
          resolve();
        } else {
          reject(err);
        }
      });
    });
  }

  try {
    await connect();
  } catch (e) {
    context.log("Cannot connect to database", e);
    context.res = {
      status: 500,
      body: "Cannot connect to database",
    };
    return;
  }

  function query(q) {
    return new Promise((resolve, reject) => {
      con.query(q, function (err, result) {
        if (!err) {
          resolve(result);
        } else {
          reject(err);
        }
      });
    });
  }

  query = query.bind(con);

  try {
    await query("TRUNCATE TABLE posts_tags;");
  } catch (e) {
    context.log("Cannot delete posts tags", e);
    context.res = {
      status: 500,
      body: "Cannot delete posts tags",
    };
    return;
  }

  try {
    await query("TRUNCATE TABLE posts_meta;");
  } catch (e) {
    context.log("Cannot delete posts meta");
    context.res = {
      status: 500,
      body: "Cannot delete posts meta",
    };
    return;
  }

  try {
    await query("TRUNCATE TABLE posts_authors;");
  } catch (e) {
    context.log("Cannot delete posts authors");
    context.res = {
      status: 500,
      body: "Cannot delete posts authors",
    };
    return;
  }

  try {
    await query("SET FOREIGN_KEY_CHECKS = 0;");
    await query("TRUNCATE TABLE posts;");
    await query("SET FOREIGN_KEY_CHECKS = 1;");
  } catch (e) {
    context.log("Cannot delete posts", e);
    context.res = {
      status: 500,
      body: "Cannot delete posts",
    };
    return;
  }

  context.res = {
    status: 200,
    body: "Deleted all posts",
  };
};
